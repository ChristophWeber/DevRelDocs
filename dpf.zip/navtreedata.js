/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Data Processing Framework: C++ APIs", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "Concepts and Terminology", "md_cpp_doc_02_Concepts.html", null ],
    [ "Ways of Using DPF", "md_cpp_doc_03_Ways_of_Using.html", null ],
    [ "Using DPF: Step by Step", "md_cpp_doc_05_Using_DPF.html", null ],
    [ "Debugging DPF", "md_cpp_doc_06_Debugging_DPF.html", null ],
    [ "DPF XML Files", "md_cpp_doc_07_DPF_XML_Files.html", null ],
    [ "Operators", "dataProcessingDoc.html", null ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"CompleteRST_8cpp-example.html",
"classansys_1_1dpf_1_1ExternalStream.html",
"classansys_1_1dpf_1_1LabelSpace.html#a13b9bdced162f48db88fce361a9e6207",
"classansys_1_1dpf_1_1Operator.html#a0875bb76f8121ba69f3e5e001deb7ea2",
"classansys_1_1dpf_1_1OperatorConfig.html#a8401495df9777cc8a53f35ecaca55460",
"classansys_1_1dpf_1_1Result.html#a439090991ae8107589374384bfca4933",
"classansys_1_1dpf_1_1ScopingsContainer.html#a989ff8e9da5f347ef75dbdcce9a9e6e1",
"classansys_1_1dpf_1_1Workflow.html#a4b4bdbd4860a8604c9116550307f9f52",
"classansys_1_1dpf_1_1core.html#ae2e440cbaacff372ab16a894ebd58523"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';