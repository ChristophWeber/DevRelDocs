/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Data Processing Framework: C++ APIs", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "Concepts and Terminology", "md_cpp_doc_02_Concepts.xhtml", null ],
    [ "Ways of Using DPF", "md_cpp_doc_03_Ways_of_Using.xhtml", null ],
    [ "Using DPF: Step by Step", "md_cpp_doc_05_Using_DPF.xhtml", null ],
    [ "Debugging DPF", "md_cpp_doc_06_Debugging_DPF.xhtml", null ],
    [ "DPF XML Files", "md_cpp_doc_07_DPF_XML_Files.xhtml", null ],
    [ "Operators", "dataProcessingDoc.xhtml", null ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ],
        [ "Enumerator", "namespacemembers_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.xhtml", [
      [ "Data Structures", "annotated.xhtml", "annotated_dup" ],
      [ "Data Structure Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Enumerations", "functions_enum.xhtml", null ],
        [ "Enumerator", "functions_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Examples", "examples.xhtml", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"CompleteRST_8cpp-example.xhtml",
"classansys_1_1dpf_1_1ExternalStream.xhtml",
"classansys_1_1dpf_1_1LabelSpace.xhtml#a13b9bdced162f48db88fce361a9e6207",
"classansys_1_1dpf_1_1Operator.xhtml#a0875bb76f8121ba69f3e5e001deb7ea2",
"classansys_1_1dpf_1_1OperatorConfig.xhtml#a8401495df9777cc8a53f35ecaca55460",
"classansys_1_1dpf_1_1Result.xhtml#a439090991ae8107589374384bfca4933",
"classansys_1_1dpf_1_1ScopingsContainer.xhtml#a989ff8e9da5f347ef75dbdcce9a9e6e1",
"classansys_1_1dpf_1_1Workflow.xhtml#a4b4bdbd4860a8604c9116550307f9f52",
"classansys_1_1dpf_1_1core.xhtml#ae2e440cbaacff372ab16a894ebd58523"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';