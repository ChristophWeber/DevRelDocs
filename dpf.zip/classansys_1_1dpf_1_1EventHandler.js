var classansys_1_1dpf_1_1EventHandler =
[
    [ "EventNature", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640", [
      [ "eOperatorStarted", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640a2cc032c33b1b3d8906a99ced4711047f", null ],
      [ "eOperatorFinished", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640a0700941093fa292915f9618bb0b61d84", null ],
      [ "eOperatorSentException", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640a93548451bb604b25b1b48544f69f5d94", null ],
      [ "eOperatorError", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640a0f25376abadec81fa52570e79d36d05f", null ],
      [ "eOperatorMakeSomeProgress", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640a464a5c45643457a27c1465574121ddf6", null ],
      [ "eOperatorWarning", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640af1894e7491fc61198867494dcc74bfac", null ],
      [ "eOperatorAddedInWorkflow", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640ad9626a0a09879a7183a76e08746cdcd1", null ],
      [ "eOperatorDelegatedRun", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640abeef70561c2a67ebb5d1d80f874018ec", null ],
      [ "eSessionWorkflowAdded", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640a3a282aed20a3d810ba9992e4727ee076", null ],
      [ "eWorkflowEvaluationStarted", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640ac8ff87a9082ab3365a799654b0c8ff1c", null ],
      [ "eWorkflowEvaluationFinished", "classansys_1_1dpf_1_1EventHandler.html#aa5dbd9875e86799e977a4ef66e78d640ae0689b714a39e93dcbc855b06abc3f50", null ]
    ] ]
];