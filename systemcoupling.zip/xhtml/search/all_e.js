var searchData=
[
  ['quantitytype_0',['quantityType',['../struct_sysc_variable.html#ac986a066454132f9f70180349586ab8b',1,'SyscVariable']]],
  ['quantitytype_1',['QuantityType',['../group___system_coupling_participant_a_p_is.html#gab4cbdd3230a1cb38956f5b93f941f89b',1,'sysc']]]
];
