var searchData=
[
  ['addcouplinginterface_0',['addCouplingInterface',['../classsysc_1_1_system_coupling.html#ae4c93f4502c9df950fddddab3aab5eec',1,'sysc::SystemCoupling::addCouplingInterface(const CouplingInterface &amp;couplingInterface)'],['../classsysc_1_1_system_coupling.html#ae1f7fe88e678c07cde61acff8742b608',1,'sysc::SystemCoupling::addCouplingInterface(const CouplingInterface &amp;couplingInterface, bool autoGenerateTransfers)']]],
  ['adddatatransfer_1',['addDataTransfer',['../classsysc_1_1_coupling_interface.html#ab1230f4b0c7dc52fff73d1ddcd67f03e',1,'sysc::CouplingInterface']]],
  ['addinputvariable_2',['addInputVariable',['../classsysc_1_1_region.html#a018cbfef9eee8c3d2cd3b20084783390',1,'sysc::Region']]],
  ['addintegerattribute_3',['addIntegerAttribute',['../classsysc_1_1_variable.html#ae6fed92c7d5f748b3e26898af932eb46',1,'sysc::Variable']]],
  ['addoutputvariable_4',['addOutputVariable',['../classsysc_1_1_region.html#a96143a5b4d943e47d335d74fa1f827be',1,'sysc::Region']]],
  ['addrealattribute_5',['addRealAttribute',['../classsysc_1_1_variable.html#ab296b04988b750113600bcc4e302ae3c',1,'sysc::Variable']]],
  ['addregion_6',['addRegion',['../classsysc_1_1_system_coupling.html#afd8d4beebb3a46d80c9f9fcddc385db2',1,'sysc::SystemCoupling']]],
  ['addsideoneregion_7',['addSideOneRegion',['../classsysc_1_1_coupling_interface.html#ab7a385065f0fde034baa88a88f274946',1,'sysc::CouplingInterface']]],
  ['addsidetworegion_8',['addSideTwoRegion',['../classsysc_1_1_coupling_interface.html#a5afdb8ffa5c06d66fe30e6f150230b67',1,'sysc::CouplingInterface']]]
];
